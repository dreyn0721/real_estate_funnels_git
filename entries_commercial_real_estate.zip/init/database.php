<?php


$host = "localhost";
$user = "root";
$pass = "";
$dbname = "dreyn";


// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);