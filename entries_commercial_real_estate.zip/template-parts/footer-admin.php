
  </main>

  <footer>
    <div class="container text-center">
      <p class="footer-text">  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus condimentum. 
        &copy;<?=date("Y");?> All rights reserved.</p>
    </div>
  </footer>




  <script type="text/javascript">
    jQuery(document).ready(function(){



    });
  </script>
</body>
</html>