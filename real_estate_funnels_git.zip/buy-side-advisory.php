<?php
// Vars
$page = "buy-side-advisory";
$pagetitle = "Buy Side Advisory | AR";
$description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum non euismod dolor. Integer sapien ipsum, dapibus eget bibendum sed nullam sodales.";


include("template-parts/header.php"); ?>

	<section>
		x
	</section>

<?php include("template-parts/footer.php"); ?>